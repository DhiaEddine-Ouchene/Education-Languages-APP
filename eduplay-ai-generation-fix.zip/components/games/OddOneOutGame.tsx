"use client";

import React, { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { CheckCircle, XCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface GameItem {
  id: string;
  word: string;
  translation: string;
  exampleSentence?: string | null;
  // Rich odd-one-out fields (from AI generation, see lib/game-schemas.ts)
  words?: string[];
  oddWord?: string;
  category?: string;
}

export interface OddOneOutProps {
  items: GameItem[];
  settings?: any;
  onComplete: (score: number, total: number) => void;
}

type Round = { words: string[]; oddWord: string; category: string };

export function OddOneOutGame({ items, settings, onComplete }: OddOneOutProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);

  // Build real odd-one-out rounds from AI-generated data when present.
  // Fall back to synthesizing a round from the flat word list (legacy games
  // created before this field existed) so nothing breaks.
  const rounds: Round[] = React.useMemo(() => {
    const hasRichData = items.some((i) => Array.isArray(i.words) && i.oddWord);
    if (hasRichData) {
      return items
        .filter((i) => Array.isArray(i.words) && i.words.length >= 4 && i.oddWord)
        .map((i) => ({ words: i.words as string[], oddWord: i.oddWord as string, category: i.category || "this group" }));
    }
    // Legacy fallback: group words 4 at a time, using a random word's
    // translation-language pair as the "odd" one out of that batch.
    const groups: Round[] = [];
    for (let i = 0; i + 3 < items.length; i += 4) {
      const batch = items.slice(i, i + 4);
      const oddPick = batch[Math.floor(Math.random() * batch.length)];
      groups.push({ words: batch.map((b) => b.word), oddWord: oddPick.word, category: "this set of words" });
    }
    return groups;
  }, [items]);

  const [shuffledWords, setShuffledWords] = useState<string[]>([]);
  const round = rounds[currentIndex];

  useEffect(() => {
    if (!round) return;
    setShuffledWords([...round.words].sort(() => 0.5 - Math.random()));
    setSelected(null);
    setIsCorrect(null);
  }, [currentIndex, round]);

  if (!round) {
    return null;
  }

  const selectWord = (word: string) => {
    if (selected !== null) return;
    setSelected(word);
    const correct = word === round.oddWord;
    setIsCorrect(correct);
    if (correct) setScore((s) => s + 1);
  };

  const handleNext = () => {
    if (currentIndex < rounds.length - 1) {
      setCurrentIndex((c) => c + 1);
    } else {
      onComplete(score, rounds.length);
    }
  };

  return (
    <div className="bg-[#f8f9ff] text-[#0b1c30] p-4 md:p-8 rounded-xl max-w-4xl mx-auto flex flex-col min-h-[600px] relative overflow-hidden">
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-red-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-2xl mx-auto mb-8 z-10">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Round {currentIndex + 1} of {rounds.length}
          </span>
          <span className="text-xs font-bold text-primary">{Math.round((currentIndex / rounds.length) * 100)}%</span>
        </div>
        <div className="h-2 w-full bg-[#dce9ff] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#4edea3] shadow-[0_0_15px_rgba(78,222,163,0.5)] rounded-full transition-all duration-700"
            style={{ width: `${(currentIndex / rounds.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="mb-10 flex flex-col items-center gap-3 z-10 text-center">
        <div className="px-8 py-2.5 rounded-full text-sm font-bold shadow-md uppercase tracking-wide bg-red-500 text-white">
          Find the odd one out
        </div>
        <p className="text-slate-500 text-lg">
          All but one of these belong to <span className="font-semibold text-primary">{round.category}</span> — which one doesn't?
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 px-4 md:px-0 z-10 flex-grow content-center">
        {shuffledWords.map((w, i) => {
          const isSelected = selected === w;
          const isTheOdd = w === round.oddWord;
          const showCorrect = selected !== null && isTheOdd;
          const showWrong = isSelected && !isTheOdd;

          return (
            <button
              key={i}
              disabled={selected !== null}
              onClick={() => selectWord(w)}
              className={cn(
                "group p-8 rounded-2xl flex flex-col items-center justify-center gap-3 shadow-sm transition-all duration-200 border-b-4 active:translate-y-1 active:border-b-0",
                selected === null
                  ? "bg-white border-[#c2c6d6] hover:border-red-400 hover:-translate-y-1 hover:shadow-md cursor-pointer"
                  : "cursor-default opacity-90",
                showCorrect ? "border-green-500 bg-green-100 text-green-800" : "",
                showWrong ? "border-red-500 bg-red-100 text-red-800 animate-[shake_0.4s_ease-in-out]" : ""
              )}
            >
              <span className="text-2xl font-bold transition-colors">{w}</span>
              {selected !== null && isTheOdd && <CheckCircle className="w-5 h-5 text-green-600" />}
              {showWrong && <XCircle className="w-5 h-5 text-red-500" />}
            </button>
          );
        })}
      </div>

      {selected !== null && (
        <div className="mt-8 flex flex-col items-center gap-4 animate-in fade-in z-10">
          <p className={cn("text-sm font-semibold", isCorrect ? "text-green-600" : "text-red-500")}>
            {isCorrect ? "Correct!" : `Not quite — "${round.oddWord}" is the odd one out.`}
          </p>
          <Button size="lg" onClick={handleNext} className="px-8 rounded-full shadow-md text-lg h-14 bg-green-600 hover:bg-green-700">
            {currentIndex < rounds.length - 1 ? "Next Round" : "Finish Game"}
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
      )}

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-8px); }
          75% { transform: translateX(8px); }
        }
      `}} />
    </div>
  );
}
