export type GameItem = {
  id: string;
  word: string;
  translation: string;
  audioUrl: string | null;
  imageUrl: string | null;
  exampleSentence: string | null;

  // ── Optional rich fields, populated when AI-generated per-game-type
  // content is available (see lib/game-schemas.ts + adapt-generated-game.ts).
  // Every field below is optional so plain vocabulary-list items (the old
  // fallback) still satisfy this type.
  synonym?: string;
  antonym?: string;
  distractors?: string[];
  hint?: string;

  words?: string[]; // odd-one-out group
  oddWord?: string;
  category?: string;

  imageSearchTerm?: string;
  imageTerm?: string;

  baseWord?: string;
  correctPartners?: string[];
  wrongPartners?: string[];

  wordA?: string;
  wordB?: string;

  scenario?: string;
  lines?: { speaker: string; text: string; isBlank: boolean }[];
  blanks?: { lineIndex: number; correctAnswer: string; distractors: string[] }[];

  correctSentence?: string;
  incorrectSentences?: string[];

  sentenceWithError?: string;
  wrongPart?: string;
  correction?: string;
  ruleExplanation?: string;

  sentenceWithBlank?: string;
  baseVerbForm?: string;
  correctConjugatedForm?: string;
  correctWord?: string;

  verb?: string;
  tense?: string;
  forms?: { pronoun: string; form: string }[];

  question?: string;
  options?: string[];
  correctOption?: string;
  explanation?: string;

  dragItems?: string[];
  dragCategories?: string[];
  correctMapping?: Record<string, string>;

  writingPrompt?: string;
  wordBank?: string[];

  sentence?: string;
  clue?: string;
};

export type GameSettings = {
  difficulty?: string;
  timer?: number;
  hints?: boolean;
  audioAutoplay?: boolean;
  shuffle?: boolean;
};

export type GameProps = {
  items: GameItem[];
  settings: GameSettings;
  onComplete: (correct: number, total: number) => void;
};

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function speak(text: string, rate = 1) {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  const u = new SpeechSynthesisUtterance(text);
  u.rate = rate;
  window.speechSynthesis.speak(u);
}

export function playAudio(item: GameItem, rate = 1) {
  if (item.audioUrl) {
    const a = new Audio(item.audioUrl);
    a.playbackRate = rate;
    void a.play();
  } else {
    speak(item.word, rate);
  }
}
