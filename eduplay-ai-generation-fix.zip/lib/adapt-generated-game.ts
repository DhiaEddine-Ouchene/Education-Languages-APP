// ── Adapts AI-generated per-game-type content into player-ready items ──
//
// `generateGame()` (see lib/generate-game.ts + lib/game-schemas.ts) produces
// content shaped exactly like the Zod schema for the game's type — e.g. an
// ODD_ONE_OUT result looks like { items: [{ words, oddWord, category }] }.
//
// The game pages previously ignored this entirely and always built `items`
// straight from the plain vocabulary list (word/translation/exampleSentence),
// which is why "Generate with AI" never seemed to fill in anything beyond a
// word list — the richer generated data was saved to `game.settings.generated`
// but nothing ever read it back out for play.
//
// This function is the single place that normalizes either source into the
// `GameItem[]` shape the player components expect, with a stable `id` per row
// so React keys and progress tracking keep working.
import type { GameItem } from "@/components/games/types";

type VocabItem = {
  id: string;
  word: string;
  translation: string;
  audioUrl: string | null;
  imageUrl: string | null;
  exampleSentence: string | null;
};

function withId(index: number, fields: Partial<GameItem>): GameItem {
  return {
    id: `gen-${index}`,
    word: "",
    translation: "",
    audioUrl: null,
    imageUrl: null,
    exampleSentence: null,
    ...fields,
  };
}

/**
 * @param gameType   Prisma GameType enum value, e.g. "ODD_ONE_OUT"
 * @param generated  The raw value of game.settings.generated (unknown/untrusted shape)
 * @param fallback   The game's plain vocabulary list, used when there is no
 *                   valid generated content yet (e.g. never generated, or the
 *                   game was built manually from the word list).
 */
export function adaptGeneratedGame(
  gameType: string,
  generated: unknown,
  fallback: VocabItem[]
): GameItem[] {
  const items = (generated as any)?.items;

  if (!Array.isArray(items) || items.length === 0) {
    // Nothing generated yet (or old/invalid data) — use the plain vocabulary list.
    return fallback.map((i) => ({ ...i }));
  }

  switch (gameType) {
    case "FLASHCARD":
    case "MEMORY":
    case "FLASHCARD_3D":
    case "WORD_MEANING_MATCH":
      return items.map((it: any, i: number) =>
        withId(i, {
          word: it.word,
          translation: it.translation,
          exampleSentence: it.exampleSentence ?? null,
        })
      );

    case "WORD_SCRAMBLE":
      return items.map((it: any, i: number) =>
        withId(i, { word: it.word, hint: it.hint, translation: it.hint, exampleSentence: it.hint })
      );

    case "SYNONYM_ANTONYM":
      return items.map((it: any, i: number) =>
        withId(i, {
          word: it.word,
          synonym: it.synonym,
          antonym: it.antonym,
          distractors: it.distractors,
          translation: it.synonym, // fallback for older component paths
        })
      );

    case "ODD_ONE_OUT":
      return items.map((it: any, i: number) =>
        withId(i, { words: it.words, oddWord: it.oddWord, category: it.category, word: it.category })
      );

    case "PICTURE_TO_WORD":
      return items.map((it: any, i: number) =>
        withId(i, { word: it.word, imageSearchTerm: it.imageSearchTerm, distractors: it.distractors })
      );

    case "COLLOCATION_BUILDER":
      return items.map((it: any, i: number) =>
        withId(i, {
          baseWord: it.baseWord,
          word: it.baseWord,
          correctPartners: it.correctPartners,
          wrongPartners: it.wrongPartners,
        })
      );

    case "MINIMAL_PAIR":
      return items.map((it: any, i: number) =>
        withId(i, { wordA: it.wordA, wordB: it.wordB, word: it.wordA, translation: it.wordB })
      );

    case "SPEED_ROUND":
      return items.map((it: any, i: number) =>
        withId(i, { word: it.word, imageTerm: it.imageTerm, distractors: it.distractors })
      );

    case "SITUATION_DIALOGUE_FILL":
      return items.map((it: any, i: number) =>
        withId(i, { scenario: it.scenario, lines: it.lines, blanks: it.blanks })
      );

    case "WORD_IN_CONTEXT":
      return items.map((it: any, i: number) =>
        withId(i, {
          word: it.word,
          correctSentence: it.correctSentence,
          incorrectSentences: it.incorrectSentences,
        })
      );

    case "SENTENCE_BUILDER":
      return items.map((it: any, i: number) =>
        withId(i, { correctSentence: it.correctSentence, exampleSentence: it.correctSentence, word: it.correctSentence })
      );

    case "ERROR_SPOTTING":
      return items.map((it: any, i: number) =>
        withId(i, {
          sentenceWithError: it.sentenceWithError,
          wrongPart: it.wrongPart,
          correction: it.correction,
          ruleExplanation: it.ruleExplanation,
          // Compatibility fields so this still renders in the generic QuizGame
          // until a dedicated ErrorSpottingGame component is built:
          word: it.sentenceWithError,
          translation: it.correction,
        })
      );

    case "FILL_BLANK_GRAMMAR":
      return items.map((it: any, i: number) =>
        withId(i, {
          sentenceWithBlank: it.sentenceWithBlank,
          baseVerbForm: it.baseVerbForm,
          correctConjugatedForm: it.correctConjugatedForm,
          word: it.sentenceWithBlank,
          translation: it.correctConjugatedForm,
        })
      );

    case "VERB_CONJUGATION":
      return items.map((it: any, i: number) =>
        withId(i, { verb: it.verb, tense: it.tense, forms: it.forms, word: it.verb, translation: it.tense })
      );

    case "MULTIPLE_CHOICE_GRAMMAR":
    case "QUIZ":
      return items.map((it: any, i: number) =>
        withId(i, {
          question: it.question,
          options: it.options,
          correctOption: it.correctOption,
          explanation: it.explanation,
          word: it.question,
          translation: it.correctOption,
        })
      );

    case "DRAG_DROP":
      return items.map((it: any, i: number) =>
        withId(i, { dragItems: it.items, dragCategories: it.categories, correctMapping: it.correctMapping })
      );

    case "STORY":
      return items.map((it: any, i: number) =>
        withId(i, { writingPrompt: it.writingPrompt, wordBank: it.wordBank, word: it.writingPrompt })
      );

    case "FILL_BLANK":
    case "FILL_GAP_WORD":
    case "LISTEN_FILL_WORD":
    case "SPEAK_FILL_WORD":
      return items.map((it: any, i: number) =>
        withId(i, {
          sentenceWithBlank: it.sentenceWithBlank,
          correctWord: it.correctWord,
          word: it.sentenceWithBlank,
          translation: it.correctWord,
        })
      );

    case "DICTATION":
    case "LISTEN_FILL_SENTENCE":
    case "SPEAK_FILL_SENTENCE":
      return items.map((it: any, i: number) =>
        withId(i, { sentence: it.sentence, word: it.sentence, exampleSentence: it.sentence })
      );

    case "CROSSWORD":
      return items.map((it: any, i: number) =>
        withId(i, { word: it.word, clue: it.clue, translation: it.clue })
      );

    default:
      return fallback.map((i) => ({ ...i }));
  }
}
