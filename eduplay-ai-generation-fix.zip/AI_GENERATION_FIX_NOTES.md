# What was actually broken, and what this patch fixes

## Root cause

There were two separate bugs stacked on top of each other:

1. **`lib/game-schemas.ts` collapsed ~20 different game types into 4 generic
   schemas** (`WORD_PAIR_SCHEMA`, `SENTENCE_FILL_SCHEMA`, `QUIZ_QUESTION_SCHEMA`,
   `AUDIO_RESPONSE_SCHEMA`). So no matter which game type a teacher picked —
   Odd One Out, Collocation, Picture to Word, Dialogue Fill, Minimal Pair,
   Error Spotting, Drag & Drop — the AI prompt only ever asked for
   `word` + `translation` + `exampleSentence` (or a generic sentence-fill
   shape). That's the literal reason "Generate with AI" only ever produced a
   set of words: **the prompt sent to the model never asked for anything else.**

2. **Even the rich data that *was* generated was never used.** `generateGame()`
   saved its result to `game.settings.generated`, but both play pages
   (`app/learn/game/[id]/page.tsx` and `app/dashboard/games/[id]/preview/page.tsx`)
   built the player's `items` prop exclusively from `game.vocabularySet.items`
   — the plain word list — and never looked at `settings.generated` at all.
   So even a perfect generation would never reach the screen.

## What this patch fixes

- **`lib/game-schemas.ts`** — rewritten from scratch. Every game type now has
  its own Zod schema and prompt with the exact fields it needs (see table
  below). The model is told precisely what to fill in per game type instead
  of a generic template.
- **`lib/adapt-generated-game.ts`** (new) — normalizes whichever shape a game
  type produces into the `GameItem[]` shape the player components read,
  falling back to the plain vocabulary list only when nothing has been
  generated yet (so old games still work).
- **`app/learn/game/[id]/page.tsx`** and **`app/dashboard/games/[id]/preview/page.tsx`**
  — now actually read `game.settings.generated` and run it through the
  adapter, instead of only ever using the plain word list.
- **`components/games/types.ts`** — `GameItem` extended with the optional
  rich fields each game type can now carry (all optional, so nothing existing
  breaks).
- **`components/games/OddOneOutGame.tsx`** — this component was not an
  odd-one-out game at all; it was a "match the translation" multiple-choice
  game with the wrong label. Rewritten so it actually shows a group of words,
  asks which one doesn't belong, and reveals the category.
- **`components/games/MinimalPairMatchGame.tsx`** — previously invented its
  own decoy word (e.g. the word + "s") instead of using a real minimal pair.
  Now uses the AI-generated `wordB` when available.

## Per-game-type fields now generated (matches your spec)

| Game type | Fields generated |
|---|---|
| Flashcard / Memory / 3D Flashcard | word, translation, exampleSentence |
| Word & Meaning | word, translation (definition) |
| Word Scramble | word, hint |
| Synonym/Antonym | word, synonym, antonym, distractors |
| Odd One Out | words[4-5], oddWord, category |
| Picture to Word | word, imageSearchTerm, distractors |
| Collocation | baseWord, correctPartners, wrongPartners |
| Minimal Pair | wordA, wordB |
| Speed Round | word, imageTerm, distractors |
| Dialogue Fill | scenario, lines[], blanks[] (per-blank distractors) |
| Word in Context | word, correctSentence, incorrectSentences |
| Crossword | word, clue (definition-based) |
| Sentence Builder | correctSentence |
| Error Spotting | sentenceWithError, wrongPart, correction, ruleExplanation |
| Fill Blank (grammar) | sentenceWithBlank, baseVerbForm, correctConjugatedForm |
| Verb Conjugation | verb, tense, forms (I/you/he-she/we/they) |
| Multiple Choice (grammar) / Quiz | question, options[4], correctOption, explanation |
| Drag & Drop | items[], categories[], correctMapping |
| Story | writingPrompt, wordBank |
| Dictation / Listen & Reorder / Speak the Sentence | sentence |
| Listen & Fill Word / Speak the Word / Fill Gap | sentenceWithBlank, correctWord |

## What still needs follow-up work (be aware of this)

Several player *components* were already very shallow before this patch —
they only ever read `word`/`translation` regardless of game type, computing
their own quiz options or decoys from sibling vocabulary items rather than
rendering the rich per-type data. This patch makes sure the **correct data
now reaches every component** (via the adapter), and fixes the two most
broken ones (Odd One Out, Minimal Pair) end-to-end. The following components
still only render the word/translation-shaped subset of what's now available,
so their in-game experience won't visibly change yet even though the richer
data is sitting there ready to use:

- **PictureToWordGame** — doesn't yet render `distractors` as answer choices
- **CollocationBuilderGame** — doesn't yet use `correctPartners` / `wrongPartners`
- **DialogueCompletionGame** — doesn't yet use `scenario` / `lines` / `blanks`
- **QuizGame** (used for Quiz, Multiple Choice Grammar, Error Spotting) — always
  derives its 4 options from sibling vocabulary items rather than the generated
  `options` / `correctOption` / `explanation`
- **FillBlankGame** / **DragDropGame** — similarly still word/translation-only
- **VERB_CONJUGATION** is generated correctly but is currently rendered through
  `FillBlankGame`, which has no concept of a conjugation table

All of these are now receiving the correct field names on each `GameItem`
(see the table in `lib/adapt-generated-game.ts`) — updating them is a
component-by-component job of reading those fields instead of the old
word/translation shortcuts, following the same pattern used in
`SynonymAntonymGame.tsx` (already correct) and the new `OddOneOutGame.tsx`.

## Recommended prompt for Claude Code

> Read `AI_GENERATION_FIX_NOTES.md`. The generation layer and data wiring are
> now fixed and generate the full field set from `lib/game-schemas.ts` per
> game type. Your job is the remaining list under "What still needs
> follow-up work": update each listed component to render the fields it's
> now receiving (see `lib/adapt-generated-game.ts` for exact field names)
> instead of deriving quiz options/decoys from sibling vocabulary items.
> Use `OddOneOutGame.tsx` as the reference pattern: real data when present,
> graceful fallback to the old behavior when it's missing (for existing
> saved games).
